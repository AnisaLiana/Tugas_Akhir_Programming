import javax.swing.*;
import java.awt.event.*;
 
/**
 * 
 * @author Yudi Setiawan
 * 
 * Menu Login Sederhana
 *
 */
 
public class Login
{
    //  Buat Objek Frame
    static JFrame frame = new JFrame();
     
    //  Buat Objek Label
    static JLabel lblUsername = new JLabel("Username");
    static JLabel lblPasswd = new JLabel("Password");
     
    //  Buat Objek TextField dan PasswordField
    static JTextField txtUsername = new JTextField();
    static JPasswordField txtPasswd = new JPasswordField();
     
    //  Buat Button Masuk
    static JButton btnMasuk = new JButton("Masuk");
     
    //  Variable
    static int count = 0;
     
    //  Method Main
    public static void main(String[] args)
    {
        //  Panggil prosedur Menu
        Menu();
         
        //  Panggil prosedur Event
        Handler();
         
    }
     
    //  Procedure untuk Layout Menu
    static void Menu()
    {
        //  Set judul frame
        frame.setTitle("Menu Login Sederhana");
         
        //  Set ukuran frame
        frame.setSize(250, 140);
         
        //  Set Posisi frame berada di tengah layar
        frame.setLocationRelativeTo(null);
         
        //  [Optional] Set tombol maximize menjadi disabled
        frame.setResizable(false);
         
        //  Set program agar program berhenti ketika tombol close di klik di frame
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         
        //  Set Visible frame  agar Frame muncul ketika program di running
        frame.setVisible(true);
         
        //  Set Layout Frame
        frame.setLayout(null);
         
        //  Memasukkan komponen Label, TextField dan Button ke dalam Frame
        frame.add(lblUsername);
        frame.add(lblPasswd);
        frame.add(txtUsername);
        frame.add(txtPasswd);
        frame.add(btnMasuk);
         
         
        //  Menentukan posisi komponen Label, TextField dan Button di dalam Frame menggunakan koordinat X dan Y
        lblUsername.setBounds(20, 20, 100, 20);
        lblPasswd.setBounds(20, 50, 100, 20);
        txtUsername.setBounds(100, 20, 130, 20);
        txtPasswd.setBounds(100, 50, 130, 20);
        btnMasuk.setBounds(20, 80, 75, 20);
         
    }
     
    //  Event Handler untuk Button Masuk
    static void Handler()
    {
        //  Event untuk Button Masuk menerima klik mouse
        btnMasuk.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                //  Mengambil nilai txtUsername
                String username = txtUsername.getText().toString();
                String passwd = txtPasswd.getText().toString();
                 
                if(username.equals("admin") && passwd.equals("admin"))
                {
                    JOptionPane.showMessageDialog(null, "Anda berhasil login");
                     
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Username/Password Anda salah!!!");
                     
 
                    //  Untuk membatasi kesalahan user dalam melakukan login
                    count++;
                }
                 
                if(count == 3)
                {
                    JOptionPane.showMessageDialog(null, "Anda sudah gagal Login sebanyak 3 kali. Harap coba lagi nanti . . .");
                    System.exit(1);
                }
            }
        }); 
    }
     
}